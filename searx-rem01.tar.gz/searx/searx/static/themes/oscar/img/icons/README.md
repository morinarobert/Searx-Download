Source: http://www.iconspedia.com/pack/flat-gradient-social-icons-4384/
License: Free for non commercial use.
